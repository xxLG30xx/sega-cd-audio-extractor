import os
import wave
import numpy as np
import audioop
from scipy.signal import butter, filtfilt

# Définir le dossier où sont stockés les fichiers .S
source_folder = "/Users/RobinCedric/Desktop/Batman"
destination_folder = os.path.join(source_folder, "audio_extracted")

# Vérifier si le dossier de destination existe, sinon le créer
if not os.path.exists(destination_folder):
    os.makedirs(destination_folder)

# Appliquer un filtre passe-bas pour réduire les bruits stridents
def apply_lowpass_filter(audio_data, sample_rate, cutoff=4000):
    nyquist = 0.5 * sample_rate
    normal_cutoff = cutoff / nyquist
    b, a = butter(3, normal_cutoff, btype='low', analog=False)
    return filtfilt(b, a, audio_data)

# Normalisation du volume sonore
def normalize_audio(audio_data):
    max_val = np.max(np.abs(audio_data))
    if max_val > 0:
        audio_data = audio_data / max_val * 127  # Ajuster au maximum 8-bit
    return audio_data.astype(np.int8)

# Convertir les échantillons PCM en format Sega CD (sign/magnitude)
def convert_to_sega_pcm(audio_data):
    converted_data = np.zeros_like(audio_data, dtype=np.uint8)
    for i, s in enumerate(audio_data):
        if s < 0:
            s = -s
            if s > 127:
                s = 127  # Clamp à -127
        else:
            if s > 126:
                s = 126  # Clamp à 126
            s |= 128  # Ajoute le bit de signe
        converted_data[i] = s
    return converted_data

# Fonction pour extraire les blocs audio d'un fichier Cinepak .S
def extract_audio_from_cinepak(file_path, output_wav_path):
    try:
        with open(file_path, "rb") as f:
            file_data = f.read()

        # Trouver toutes les entrées STAB contenant de l'audio (0xFFFFFFFF)
        entry_size = 16  # Taille standard d'une entrée STAB
        stab_offset = file_data.find(b"STAB")
        audio_entries = []

        if stab_offset != -1:
            for i in range(stab_offset, len(file_data), entry_size):
                entry = file_data[i:i+entry_size]
                if len(entry) < entry_size:
                    break
                offset = int.from_bytes(entry[0:4], "big")
                length = int.from_bytes(entry[4:8], "big")
                entry_type = int.from_bytes(entry[8:12], "big")
                if entry_type == 0xFFFFFFFF and length > 0:
                    audio_entries.append((offset, length))

        # Extraire et assembler les segments audio détectés
        if audio_entries:
            with open(file_path, "rb") as f:
                full_audio_data = b""
                for offset, length in audio_entries:
                    f.seek(offset)
                    full_audio_data += f.read(min(length, 32768))  # Lecture progressive
                
            # Convertir les données en tableau numpy
            audio_array = np.frombuffer(full_audio_data, dtype=np.int8)
            
            # Appliquer la conversion Sega PCM
            audio_array = convert_to_sega_pcm(audio_array)
            
            # Appliquer un filtre passe-bas et normaliser
            audio_array = apply_lowpass_filter(audio_array.astype(np.float32), 16000)
            audio_array = normalize_audio(audio_array)
            
            # Sauvegarder en fichier WAV
            with wave.open(output_wav_path, "wb") as wav_file:
                wav_file.setnchannels(1)  # Mono
                wav_file.setsampwidth(1)  # 8-bit PCM
                wav_file.setframerate(16000)  # Fréquence Cinepak pour Sega
                wav_file.writeframes(audio_array.tobytes())

            print(f"Extraction réussie : {output_wav_path}")
        else:
            print(f"Aucun audio détecté dans {file_path}")

    except Exception as e:
        print(f"Erreur lors de l'extraction de {file_path} : {e}")

# Lister tous les fichiers .S dans le dossier source
files = [f for f in os.listdir(source_folder) if f.endswith(".S")]

# Parcourir chaque fichier et extraire l'audio
for file in files:
    input_path = os.path.join(source_folder, file)
    output_path = os.path.join(destination_folder, f"{os.path.splitext(file)[0]}.wav")
    extract_audio_from_cinepak(input_path, output_path)

print("Extraction et correction terminées !")